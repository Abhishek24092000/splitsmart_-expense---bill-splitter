import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { AppView, Category, Currency, Expense, Group, User, RecurrenceInterval, SavingsTip } from '../types';
import { PlusIcon, BackIcon, TrashIcon, EditIcon, UserCircleIcon, LightBulbIcon } from '../constants';
import {
  generateId,
  formatDate,
  formatCurrency,
  calculateGroupBalances,
  simplifyDebts,
  getCategoryName,
  getUserName,
  getCategoryIcon,
  aggregateSpendingByCategory,
  aggregateSpendingByMonth
} from '../utils/helpers';
import { CURRENCIES_LIST, DEFAULT_CATEGORIES, getCurrencySymbol, DEFAULT_USERS } from '../constants';
import Modal from './Modal';
import { getSavingsTips } from '../services/geminiService';


// Common UI Elements (to avoid more files)
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
}

const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', size = 'md', className = '', ...props }) => {
  const baseClasses = "font-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-darkSurface transition-all duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed";
  const sizeClasses = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-4 py-2 text-base",
    lg: "px-6 py-3 text-lg",
  };
  const variantClasses = {
    primary: "bg-primary hover:bg-primary-dark text-white focus:ring-primary-light",
    secondary: "bg-secondary hover:bg-secondary-dark text-white focus:ring-secondary-light",
    danger: "bg-red-600 hover:bg-red-700 text-white focus:ring-red-500",
    ghost: "bg-transparent hover:bg-gray-200 dark:hover:bg-gray-700 text-primary dark:text-secondary focus:ring-primary-light",
  };
  return (
    <button className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
};

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}
const Input: React.FC<InputProps> = ({ label, id, error, className, ...props }) => (
  <div className="w-full">
    {label && <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-darkMuted mb-1">{label}</label>}
    <input
      id={id}
      className={`block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-darkText sm:text-sm ${error ? 'border-red-500' : ''} ${className}`}
      {...props}
    />
    {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
  </div>
);

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
}
const Select: React.FC<SelectProps> = ({ label, id, children, error, className, ...props }) => (
 <div className="w-full">
    {label && <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-darkMuted mb-1">{label}</label>}
    <select
      id={id}
      className={`block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-darkText sm:text-sm ${error ? 'border-red-500' : ''} ${className}`}
      {...props}
    >
      {children}
    </select>
    {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
  </div>
);


// Prop types for Views
interface ViewProps {
  setCurrentView: (view: AppView, params?: any) => void;
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  categories: Category[];
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
  expenses: Expense[];
  setExpenses: React.Dispatch<React.SetStateAction<Expense[]>>;
  groups: Group[];
  setGroups: React.Dispatch<React.SetStateAction<Group[]>>;
  currentCurrency: Currency;
  setCurrentCurrency: React.Dispatch<React.SetStateAction<Currency>>;
  viewParams?: any; // For passing IDs etc. to views
}


// DASHBOARD VIEW
export const DashboardView: React.FC<ViewProps> = ({ expenses, categories, currentCurrency, groups, users, setCurrentView }) => {
  const [savingsTips, setSavingsTips] = useState<SavingsTip[]>([]);
  const [isLoadingTips, setIsLoadingTips] = useState(false);

  const categoryData = useMemo(() => aggregateSpendingByCategory(expenses, categories, currentCurrency), [expenses, categories, currentCurrency]);
  const monthlyData = useMemo(() => aggregateSpendingByMonth(expenses, currentCurrency), [expenses, currentCurrency]);
  
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

  const totalSpentThisMonth = useMemo(() => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    return expenses
      .filter(e => !e.isRecurring && e.currency === currentCurrency && new Date(e.date).getMonth() === currentMonth && new Date(e.date).getFullYear() === currentYear)
      .reduce((sum, e) => sum + e.amount, 0);
  }, [expenses, currentCurrency]);

  const handleGetSavingsTips = useCallback(async () => {
    setIsLoadingTips(true);
    const tips = await getSavingsTips(expenses, categories, currentCurrency);
    setSavingsTips(tips.map(tip => ({ id: generateId(), tip })));
    setIsLoadingTips(false);
  }, [expenses, categories, currentCurrency]);

  useEffect(() => {
    // Automatically fetch tips on initial load if there's some data
    if (expenses.length > 0 && categories.length > 0) {
        handleGetSavingsTips();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Empty dependency array to run once on mount

  return (
    <div className="p-4 space-y-6">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-darkText">Dashboard</h1>
      
      <div className="p-4 bg-white dark:bg-darkSurface shadow rounded-lg">
        <h2 className="text-xl font-semibold text-gray-700 dark:text-darkMuted mb-2">This Month's Spending</h2>
        <p className="text-3xl font-bold text-primary dark:text-secondary">{formatCurrency(totalSpentThisMonth, currentCurrency)}</p>
      </div>

      {categoryData.length > 0 && (
        <div className="p-4 bg-white dark:bg-darkSurface shadow rounded-lg">
          <h2 className="text-xl font-semibold text-gray-700 dark:text-darkMuted mb-2">Spending by Category</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={categoryData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => formatCurrency(value, currentCurrency)} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}

      {monthlyData.length > 0 && (
         <div className="p-4 bg-white dark:bg-darkSurface shadow rounded-lg">
          <h2 className="text-xl font-semibold text-gray-700 dark:text-darkMuted mb-2">Monthly Spending Trend</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyData}>
              <XAxis dataKey="month" />
              <YAxis tickFormatter={(value: number) => getCurrencySymbol(currentCurrency) + value} />
              <Tooltip formatter={(value: number) => formatCurrency(value, currentCurrency)} />
              <Legend />
              <Bar dataKey="value" fill={COLORS[1]} name={`Spending (${currentCurrency})`}/>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="p-4 bg-white dark:bg-darkSurface shadow rounded-lg">
        <h2 className="text-xl font-semibold text-gray-700 dark:text-darkMuted mb-2">Smart Savings Tips</h2>
        {isLoadingTips ? (
          <div className="flex justify-center items-center h-20">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary dark:border-secondary"></div>
            <p className="ml-3 text-gray-600 dark:text-darkMuted">Fetching tips...</p>
          </div>
        ) : savingsTips.length > 0 ? (
          <ul className="space-y-2">
            {savingsTips.map(tip => (
              <li key={tip.id} className="flex items-start p-2 bg-blue-50 dark:bg-blue-900/30 rounded-md">
                <span className="text-blue-500 dark:text-blue-400 mr-2">{LightBulbIcon}</span>
                <span className="text-gray-700 dark:text-darkText">{tip.tip}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-600 dark:text-darkMuted">No tips generated yet. Add some expenses or click below.</p>
        )}
        <Button onClick={handleGetSavingsTips} className="mt-4" variant="secondary" disabled={isLoadingTips}>
          <span className="flex items-center">{LightBulbIcon} <span className="ml-2">Get New Savings Tips</span></span>
        </Button>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Button onClick={() => setCurrentView(AppView.EXPENSES)} className="w-full py-3 text-lg">View All Expenses</Button>
          <Button onClick={() => setCurrentView(AppView.GROUPS)} className="w-full py-3 text-lg">Manage Groups</Button>
      </div>
    </div>
  );
};


// EXPENSE FORM
interface ExpenseFormProps extends ViewProps {
  expenseToEdit?: Expense; // For editing
  groupId?: string; // If adding expense to a specific group
}

export const ExpenseForm: React.FC<ExpenseFormProps> = ({
  setCurrentView, users, categories, setCategories, expenses, setExpenses, currentCurrency, groups, expenseToEdit, viewParams
}) => {
  const { groupId: preselectedGroupId, expenseId: editExpenseId } = viewParams || {};
  const editingExpense = editExpenseId ? expenses.find(e => e.id === editExpenseId) : undefined;

  const [amount, setAmount] = useState(editingExpense ? editingExpense.amount.toString() : '');
  const [description, setDescription] = useState(editingExpense ? editingExpense.description : '');
  const [categoryId, setCategoryId] = useState(editingExpense ? editingExpense.categoryId : DEFAULT_CATEGORIES[0]?.id || '');
  const [date, setDate] = useState(editingExpense ? editingExpense.date : new Date().toISOString().split('T')[0]);
  const [paidByUserId, setPaidByUserId] = useState(editingExpense ? editingExpense.paidByUserId : users[0]?.id || '');
  const [notes, setNotes] = useState(editingExpense ? editingExpense.notes || '' : '');
  const [currency, setCurrency] = useState<Currency>(editingExpense ? editingExpense.currency : currentCurrency);
  
  const [isRecurring, setIsRecurring] = useState(editingExpense ? editingExpense.isRecurring : false);
  const [recurrenceInterval, setRecurrenceInterval] = useState<RecurrenceInterval | undefined>(editingExpense ? editingExpense.recurrenceInterval : RecurrenceInterval.MONTHLY);
  const [nextRecurrenceDate, setNextRecurrenceDate] = useState(editingExpense && editingExpense.nextRecurrenceDate ? editingExpense.nextRecurrenceDate : new Date().toISOString().split('T')[0]);

  const [groupId, setGroupId] = useState(editingExpense ? editingExpense.groupId : preselectedGroupId);
  const group = groups.find(g => g.id === groupId);
  
  const initialParticipants = useMemo(() => {
    if (editingExpense && editingExpense.participants) {
      return editingExpense.participants.map(p => p.userId);
    }
    return group ? group.memberIds : (users.length > 0 ? [users[0].id] : []);
  }, [editingExpense, group, users]);
  const [selectedParticipantIds, setSelectedParticipantIds] = useState<string[]>(initialParticipants);
  
  const [showCustomCategoryInput, setShowCustomCategoryInput] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryIcon, setNewCategoryIcon] = useState('💡');

  const availableUsersForGroup = group ? users.filter(u => group.memberIds.includes(u.id)) : users;

  useEffect(() => { // If group changes, update participants to all members of new group
    if(group && !editingExpense) { // only for new expenses or if group context changes
        setSelectedParticipantIds(group.memberIds);
        if (group.memberIds.length > 0 && !group.memberIds.includes(paidByUserId)) {
            setPaidByUserId(group.memberIds[0]); // Default payer to first group member if current payer not in group
        } else if (group.memberIds.length === 0 && users.length > 0) {
             setPaidByUserId(users[0].id); // Fallback if group somehow has no members
        }
    }
  }, [group, editingExpense, users, paidByUserId]);


  const handleAddCustomCategory = () => {
    if (newCategoryName.trim() === '') return;
    const newCat: Category = {
      id: generateId(),
      name: newCategoryName.trim(),
      icon: newCategoryIcon.trim() || '💲',
      isCustom: true,
    };
    setCategories(prev => [...prev, newCat]);
    setCategoryId(newCat.id);
    setNewCategoryName('');
    setNewCategoryIcon('💡');
    setShowCustomCategoryInput(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !description || !categoryId || !date || !paidByUserId) {
      alert('Please fill all required fields: Description, Amount, Date, Category, Paid By.');
      return;
    }
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      alert('Please enter a valid positive amount.');
      return;
    }
    if (groupId && selectedParticipantIds.length === 0) {
        alert('For a group expense, at least one participant must be selected.');
        return;
    }


    let expenseParticipants: { userId: string; share: number }[] | undefined = undefined;
    if (groupId && selectedParticipantIds.length > 0) {
      const sharePerParticipant = numericAmount / selectedParticipantIds.length;
      expenseParticipants = selectedParticipantIds.map(uid => ({ userId: uid, share: sharePerParticipant }));
    } else if (!groupId) { // Individual expense
      expenseParticipants = [{userId: paidByUserId, share: numericAmount}];
    }


    const expenseData: Expense = {
      id: editingExpense ? editingExpense.id : generateId(),
      amount: numericAmount,
      currency,
      date,
      categoryId,
      description,
      notes,
      paidByUserId,
      isRecurring: isRecurring && !groupId, // Recurring expenses are not for groups for simplicity
      recurrenceInterval: isRecurring && !groupId ? recurrenceInterval : undefined,
      nextRecurrenceDate: isRecurring && !groupId ? nextRecurrenceDate : undefined,
      groupId: groupId || undefined,
      participants: expenseParticipants,
    };

    if (editingExpense) {
      setExpenses(prev => prev.map(exp => exp.id === editingExpense.id ? expenseData : exp));
    } else {
      setExpenses(prev => [...prev, expenseData]);
    }
    
    setCurrentView(groupId ? AppView.GROUP_DETAILS : AppView.EXPENSES, groupId ? { groupId } : undefined);
  };

  const title = editingExpense ? "Edit Expense" : (groupId ? `Add Expense to ${group?.name}` : "Add New Expense");

  return (
    <div className="p-4">
      <div className="flex items-center mb-6">
        <Button onClick={() => setCurrentView(groupId ? AppView.GROUP_DETAILS : AppView.EXPENSES, groupId ? { groupId } : undefined)} variant="ghost" size="sm" className="mr-2">
          {BackIcon}
        </Button>
        <h1 className="text-2xl font-bold text-gray-800 dark:text-darkText">{title}</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 max-w-lg mx-auto bg-white dark:bg-darkSurface p-6 rounded-lg shadow">
        <Input label="Description" id="description" value={description} onChange={e => setDescription(e.target.value)} required />
        <div className="grid grid-cols-2 gap-4">
            <Input label="Amount" id="amount" type="number" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} required />
            <Select label="Currency" id="currency" value={currency} onChange={e => setCurrency(e.target.value as Currency)}>
            {CURRENCIES_LIST.map(c => <option key={c.code} value={c.code}>{c.code} ({c.symbol})</option>)}
            </Select>
        </div>
        <Input label="Date" id="date" type="date" value={date} onChange={e => setDate(e.target.value)} required />
        
        <Select label="Category" id="category" value={categoryId} onChange={e => setCategoryId(e.target.value)}>
          {categories.map(cat => <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>)}
        </Select>
        <Button type="button" variant="ghost" size="sm" onClick={() => setShowCustomCategoryInput(s => !s)}>
          {showCustomCategoryInput ? 'Cancel Custom' : '+ Add Custom Category'}
        </Button>
        {showCustomCategoryInput && (
          <div className="p-3 border dark:border-gray-600 rounded space-y-2 bg-gray-50 dark:bg-gray-700/50">
            <Input label="New Category Name" value={newCategoryName} onChange={e => setNewCategoryName(e.target.value)} />
            <Input label="New Category Icon (Emoji)" value={newCategoryIcon} onChange={e => setNewCategoryIcon(e.target.value)} maxLength={2} />
            <Button type="button" onClick={handleAddCustomCategory} variant="secondary" size="sm">Save Category</Button>
          </div>
        )}

        {!groupId && ( // Only show group selection if not already in a group context (i.e. preselectedGroupId is null) and not editing an existing group expense
            !(editingExpense && editingExpense.groupId) && (
            <Select label="Group (Optional)" id="group" value={groupId || ''} onChange={e => {
                const newGroupId = e.target.value || undefined;
                setGroupId(newGroupId);
                const newSelectedGroup = groups.find(g => g.id === newGroupId);
                if (newSelectedGroup) {
                    setSelectedParticipantIds(newSelectedGroup.memberIds); // Auto-select all members
                    if(newSelectedGroup.memberIds.length > 0) setPaidByUserId(newSelectedGroup.memberIds[0]); // Default payer
                } else {
                    setSelectedParticipantIds(users.length > 0 ? [users[0].id] : []); // Personal expense, default to first user
                }
            }}>
                <option value="">None (Personal Expense)</option>
                {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
            </Select>
        ))}
        
        <Select label="Paid By" id="paidBy" value={paidByUserId} onChange={e => setPaidByUserId(e.target.value)} required>
            {(group ? users.filter(u => group.memberIds.includes(u.id)) : users).map(user => (
            <option key={user.id} value={user.id}>{user.name}</option>
            ))}
        </Select>

        {groupId && group && (
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-darkMuted mb-1">Participants (split equally)</label>
            <div className="space-y-1 max-h-32 overflow-y-auto border dark:border-gray-600 p-2 rounded-md bg-gray-50 dark:bg-gray-700/50">
              {users.filter(u => group.memberIds.includes(u.id)).map(user => (
                <div key={user.id} className="flex items-center">
                  <input
                    type="checkbox"
                    id={`participant-${user.id}`}
                    checked={selectedParticipantIds.includes(user.id)}
                    onChange={e => {
                      if (e.target.checked) {
                        setSelectedParticipantIds(prev => [...prev, user.id]);
                      } else {
                        setSelectedParticipantIds(prev => prev.filter(id => id !== user.id));
                      }
                    }}
                    className="h-4 w-4 text-primary border-gray-300 dark:border-gray-500 rounded focus:ring-primary mr-2"
                  />
                  <label htmlFor={`participant-${user.id}`} className="text-sm text-gray-700 dark:text-darkText">{user.name}</label>
                </div>
              ))}
            </div>
            {selectedParticipantIds.length === 0 && <p className="text-xs text-red-500 mt-1">At least one participant must be selected for a group expense.</p>}
          </div>
        )}
        
        {!groupId && ( // Recurring options only for non-group expenses
            <div className="space-y-2 mt-4 border-t dark:border-gray-600 pt-4">
                <div className="flex items-center">
                    <input type="checkbox" id="isRecurring" checked={isRecurring} onChange={e => setIsRecurring(e.target.checked)} className="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary mr-2"/>
                    <label htmlFor="isRecurring" className="text-sm font-medium text-gray-700 dark:text-darkText">Recurring Expense (Personal Only)</label>
                </div>
                {isRecurring && (
                    <div className="grid grid-cols-2 gap-4 p-3 border dark:border-gray-600 rounded bg-gray-50 dark:bg-gray-700/50">
                        <Select label="Interval" id="recurrenceInterval" value={recurrenceInterval} onChange={e => setRecurrenceInterval(e.target.value as RecurrenceInterval)}>
                            {Object.values(RecurrenceInterval).map(interval => (
                                <option key={interval} value={interval}>{interval.charAt(0).toUpperCase() + interval.slice(1)}</option>
                            ))}
                        </Select>
                        <Input label="Next Recurrence" id="nextRecurrenceDate" type="date" value={nextRecurrenceDate} onChange={e => setNextRecurrenceDate(e.target.value)} />
                    </div>
                )}
            </div>
        )}

        <Input label="Notes (Optional)" id="notes" value={notes} onChange={e => setNotes(e.target.value)} />
        <Button type="submit" className="w-full" size="lg">
          {editingExpense ? 'Update Expense' : 'Save Expense'}
        </Button>
      </form>
    </div>
  );
};


// EXPENSES VIEW
export const ExpensesView: React.FC<ViewProps> = ({ expenses, setExpenses, categories, users, currentCurrency, setCurrentView }) => {
  const [filterCategory, setFilterCategory] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  
  const handleDeleteExpense = (expenseId: string) => {
    if (window.confirm("Are you sure you want to delete this expense?")) {
      setExpenses(prev => prev.filter(exp => exp.id !== expenseId));
    }
  };

  const filteredExpenses = expenses
    .filter(exp => !exp.groupId) // Only show personal expenses here
    .filter(exp => filterCategory ? exp.categoryId === filterCategory : true)
    .filter(exp => !exp.isRecurring) // Don't show recurring templates, only actual instances
    .filter(exp => exp.description.toLowerCase().includes(searchTerm.toLowerCase()) || (exp.notes && exp.notes.toLowerCase().includes(searchTerm.toLowerCase())) )
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="p-4">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-darkText">My Personal Expenses</h1>
        <Button onClick={() => setCurrentView(AppView.ADD_EXPENSE)} variant="primary" size="md">
          <span className="flex items-center">{PlusIcon} <span className="ml-1">Add Expense</span></span>
        </Button>
      </div>

      <div className="mb-6 grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-white dark:bg-darkSurface rounded-lg shadow">
        <Input 
            placeholder="Search by description or notes..." 
            value={searchTerm} 
            onChange={e => setSearchTerm(e.target.value)}
            label="Search Expenses"
        />
        <Select label="Filter by Category" value={filterCategory} onChange={e => setFilterCategory(e.target.value)}>
          <option value="">All Categories</option>
          {categories.map(cat => <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>)}
        </Select>
      </div>

      {filteredExpenses.length === 0 ? (
        <div className="text-center text-gray-500 dark:text-darkMuted py-12">
          <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
            <path vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
          </svg>
          <h3 className="mt-2 text-lg font-medium text-gray-900 dark:text-darkText">No expenses found</h3>
          <p className="mt-1 text-sm text-gray-500 dark:text-darkMuted">
            {searchTerm || filterCategory ? "Try adjusting your search or filters." : "Get started by adding a new expense."}
          </p>
          {!(searchTerm || filterCategory) && (
            <div className="mt-6">
                <Button onClick={() => setCurrentView(AppView.ADD_EXPENSE)} variant="primary">
                    <span className="flex items-center">{PlusIcon} <span className="ml-1">Add First Expense</span></span>
                </Button>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filteredExpenses.map(expense => (
            <div key={expense.id} className="bg-white dark:bg-darkSurface shadow-md rounded-lg p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center hover:shadow-lg transition-shadow">
              <div className="flex-grow mb-2 sm:mb-0">
                <p className="text-lg font-semibold text-gray-800 dark:text-darkText">{expense.description}</p>
                <p className="text-sm text-gray-500 dark:text-darkMuted">
                  {getCategoryIcon(expense.categoryId, categories)} {getCategoryName(expense.categoryId, categories)} | {formatDate(expense.date)}
                </p>
                 {expense.notes && <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">Notes: {expense.notes}</p>}
              </div>
              <div className="text-left sm:text-right w-full sm:w-auto">
                <p className={`text-xl font-bold ${expense.amount > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                  {formatCurrency(expense.amount, expense.currency)}
                </p>
                <div className="mt-2 sm:mt-1 space-x-2">
                    <Button onClick={() => setCurrentView(AppView.ADD_EXPENSE, { expenseId: expense.id })} variant="ghost" size="sm" aria-label="Edit" className="p-1">
                        {EditIcon}
                    </Button>
                    <Button onClick={() => handleDeleteExpense(expense.id)} variant="ghost" size="sm" className="text-red-500 hover:text-red-700 p-1" aria-label="Delete">
                        {TrashIcon}
                    </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};


// GROUPS VIEW (List and Detail)
export const GroupsView: React.FC<ViewProps> = ({ groups, setGroups, expenses, setExpenses, users, setUsers, categories, currentCurrency, setCurrentView, viewParams }) => {
  const { groupId } = viewParams || {}; // For showing group details

  const [showGroupForm, setShowGroupForm] = useState(false);
  const [groupToEdit, setGroupToEdit] = useState<Group | undefined>(undefined);
  
  // Group Form State
  const [groupName, setGroupName] = useState('');
  const [groupDescription, setGroupDescription] = useState('');
  const [groupMemberIds, setGroupMemberIds] = useState<string[]>([]);
  const [groupCurrency, setGroupCurrency] = useState<Currency>(currentCurrency);
  
  const [showUserForm, setShowUserForm] = useState(false);
  const [newUserName, setNewUserName] = useState('');

  const handleAddUser = () => {
    if(newUserName.trim() === '') return;
    const newUser: User = { id: generateId(), name: newUserName.trim() };
    setUsers(prev => [...prev, newUser]);
    setGroupMemberIds(prev => [...prev, newUser.id]); // Add to current group form
    setNewUserName('');
    setShowUserForm(false);
  }

  const resetGroupForm = () => {
    setGroupName('');
    setGroupDescription('');
    setGroupMemberIds(users.length > 0 ? [users[0].id] : []);
    setGroupCurrency(currentCurrency);
    setGroupToEdit(undefined);
  }

  const handleOpenGroupForm = (group?: Group) => {
    if (group) {
      setGroupToEdit(group);
      setGroupName(group.name);
      setGroupDescription(group.description || '');
      setGroupMemberIds(group.memberIds);
      setGroupCurrency(group.defaultCurrency);
    } else {
      resetGroupForm();
      // When creating new group, pre-select first user if available
       if (users.length > 0 && groupMemberIds.length === 0) {
        setGroupMemberIds([users[0].id]);
      }
    }
    setShowGroupForm(true);
  };
  
  const handleSaveGroup = () => {
    if (groupName.trim() === '' || groupMemberIds.length === 0) {
      alert('Group name and at least one member are required.');
      return;
    }
    const groupData: Group = {
      id: groupToEdit ? groupToEdit.id : generateId(),
      name: groupName.trim(),
      description: groupDescription.trim(),
      memberIds: groupMemberIds,
      defaultCurrency: groupCurrency,
    };
    if (groupToEdit) {
      setGroups(prev => prev.map(g => g.id === groupData.id ? groupData : g));
    } else {
      setGroups(prev => [...prev, groupData]);
    }
    setShowGroupForm(false);
    resetGroupForm();
  };

  const handleDeleteGroup = (id: string) => {
    if (window.confirm("Are you sure you want to delete this group and all its expenses? This cannot be undone.")) {
      setGroups(prev => prev.filter(g => g.id !== id));
      setExpenses(prev => prev.filter(exp => exp.groupId !== id));
      if (groupId === id) { // If current detail view is the deleted group
        setCurrentView(AppView.GROUPS);
      }
    }
  };

  // Group Details specific
  const selectedGroup = groups.find(g => g.id === groupId);
  const groupExpenses = expenses.filter(e => e.groupId === groupId && !e.isRecurring).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const groupBalances = selectedGroup ? calculateGroupBalances(groupId, expenses, groups, users) : new Map();
  const simplifiedSettlements = selectedGroup ? simplifyDebts(groupBalances, selectedGroup.defaultCurrency) : [];

  const handleDeleteGroupExpense = (expenseId: string) => {
    if (window.confirm("Delete this group expense?")) {
      setExpenses(prev => prev.filter(exp => exp.id !== expenseId));
    }
  };

  if (groupId && selectedGroup) { // DETAIL VIEW
    return (
      <div className="p-4 space-y-6">
        <div className="flex items-center mb-2">
          <Button onClick={() => setCurrentView(AppView.GROUPS)} variant="ghost" size="sm" className="mr-2 p-1">{BackIcon}</Button>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-darkText">{selectedGroup.name}</h1>
        </div>
        <p className="text-gray-600 dark:text-darkMuted">{selectedGroup.description || "No description for this group."}</p>
        <div className="flex items-center space-x-2">
            <Button onClick={() => handleOpenGroupForm(selectedGroup)} variant="secondary" size="sm"><span className="flex items-center">{EditIcon}<span className="ml-1">Edit Group</span></span></Button>
            <Button onClick={() => handleDeleteGroup(selectedGroup.id)} variant="danger" size="sm"><span className="flex items-center">{TrashIcon}<span className="ml-1">Delete Group</span></span></Button>
        </div>

        <div className="mt-6 flex justify-between items-center">
            <h2 className="text-2xl font-semibold text-gray-700 dark:text-darkText">Expenses in {selectedGroup.name}</h2>
            <Button onClick={() => setCurrentView(AppView.ADD_EXPENSE, { groupId: selectedGroup.id })} variant="primary">
                <span className="flex items-center">{PlusIcon} <span className="ml-1">Add Expense</span></span>
            </Button>
        </div>
        {groupExpenses.length === 0 ? (
           <div className="text-center text-gray-500 dark:text-darkMuted py-12">
             <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
             </svg>
             <h3 className="mt-2 text-lg font-medium text-gray-900 dark:text-darkText">No expenses yet</h3>
             <p className="mt-1 text-sm text-gray-500 dark:text-darkMuted">Add an expense to this group to see it here.</p>
           </div>
        ) : (
          <div className="space-y-3">
            {groupExpenses.map(exp => (
              <div key={exp.id} className="bg-white dark:bg-darkSurface shadow rounded-lg p-3 hover:shadow-md transition-shadow">
                <div className="flex flex-col sm:flex-row justify-between items-start">
                    <div className="flex-grow mb-2 sm:mb-0">
                        <p className="font-semibold text-gray-800 dark:text-darkText">{exp.description}</p>
                        <p className="text-xs text-gray-500 dark:text-darkMuted">
                            Paid by: {getUserName(exp.paidByUserId, users)} | {formatDate(exp.date)} | {getCategoryIcon(exp.categoryId, categories)} {getCategoryName(exp.categoryId, categories)}
                        </p>
                        {exp.participants && exp.participants.length > 0 && (
                            <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                                Split among: {exp.participants.map(p => getUserName(p.userId, users)).join(', ')}
                            </p>
                        )}
                    </div>
                    <div className="text-left sm:text-right w-full sm:w-auto">
                        <p className="font-semibold text-lg text-primary dark:text-secondary">{formatCurrency(exp.amount, exp.currency)}</p>
                         <div className="mt-1 space-x-1">
                            <Button onClick={() => setCurrentView(AppView.ADD_EXPENSE, { expenseId: exp.id, groupId: selectedGroup.id })} variant="ghost" size="sm" className="p-1">{EditIcon}</Button>
                            <Button onClick={() => handleDeleteGroupExpense(exp.id)} variant="ghost" size="sm" className="text-red-500 hover:text-red-700 p-1">{TrashIcon}</Button>
                        </div>
                    </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <h2 className="text-2xl font-semibold text-gray-700 dark:text-darkText mt-8">Balances</h2>
        {Array.from(groupBalances.entries()).length === 0 ? <p className="text-gray-500 dark:text-darkMuted">No balances to show.</p> : (
            <ul className="space-y-2 bg-white dark:bg-darkSurface shadow rounded-lg p-4">
            {Array.from(groupBalances.entries()).map(([userId, balance]) => (
                <li key={userId} className="flex justify-between items-center text-gray-700 dark:text-darkText py-2 border-b dark:border-gray-700 last:border-b-0">
                <span className="flex items-center"><span className="mr-2">{UserCircleIcon}</span> {getUserName(userId, users)}</span>
                <span className={`font-semibold ${balance > 0.001 ? 'text-green-600 dark:text-green-400' : (balance < -0.001 ? 'text-red-600 dark:text-red-400' : 'text-gray-500 dark:text-darkMuted')}`}>
                    {balance > 0.001 ? 'Is owed ' : (balance < -0.001 ? 'Owes ' : 'Settled ')}
                    {formatCurrency(Math.abs(balance), selectedGroup.defaultCurrency)}
                </span>
                </li>
            ))}
            </ul>
        )}
        
        <h2 className="text-2xl font-semibold text-gray-700 dark:text-darkText mt-8">Settle Up Suggestions</h2>
        {simplifiedSettlements.length === 0 ? 
          <div className="text-center text-green-600 dark:text-green-400 py-8 bg-green-50 dark:bg-green-900/30 rounded-lg">
            <svg className="mx-auto h-10 w-10" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="mt-2 font-semibold">Everyone is settled up!</p>
          </div> 
            : (
            <ul className="space-y-3">
            {simplifiedSettlements.map((settlement, idx) => (
                <li key={idx} className="p-4 border dark:border-gray-700 rounded-lg bg-white dark:bg-darkSurface shadow">
                <p className="text-gray-800 dark:text-darkText">
                    <span className="font-semibold">{getUserName(settlement.fromUserId, users)}</span> should pay <span className="font-semibold">{getUserName(settlement.toUserId, users)}</span>
                </p>
                <p className="text-xl font-bold text-accent dark:text-accent-light mt-1">{formatCurrency(settlement.amount, settlement.currency)}</p>
                <Button size="sm" variant="secondary" className="mt-3 opacity-50 cursor-not-allowed" title="Payment tracking not implemented">Mark as Paid (Simulated)</Button>
                </li>
            ))}
            </ul>
        )}
      </div>
    );
  }

  // LIST VIEW
  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-darkText">My Groups</h1>
        <Button onClick={() => handleOpenGroupForm()} variant="primary">
          <span className="flex items-center">{PlusIcon} <span className="ml-1">Create Group</span></span>
        </Button>
      </div>

      {groups.length === 0 ? (
        <div className="text-center text-gray-500 dark:text-darkMuted py-12">
            <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
            <h3 className="mt-2 text-lg font-medium text-gray-900 dark:text-darkText">No groups yet</h3>
            <p className="mt-1 text-sm text-gray-500 dark:text-darkMuted">Create a group to start sharing expenses with friends or family.</p>
             <div className="mt-6">
                <Button onClick={() => handleOpenGroupForm()} variant="primary">
                    <span className="flex items-center">{PlusIcon} <span className="ml-1">Create First Group</span></span>
                </Button>
            </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {groups.map(group => (
            <div key={group.id} className="bg-white dark:bg-darkSurface shadow-lg rounded-xl p-5 cursor-pointer hover:shadow-xl transition-shadow duration-200 ease-in-out flex flex-col justify-between" onClick={() => setCurrentView(AppView.GROUP_DETAILS, { groupId: group.id })}>
              <div>
                <h2 className="text-xl font-semibold text-primary dark:text-secondary mb-1 truncate">{group.name}</h2>
                <p className="text-sm text-gray-600 dark:text-darkMuted mb-2 h-10 overflow-hidden text-ellipsis">{group.description || 'No description'}</p>
                <div className="text-xs text-gray-500 dark:text-gray-400 mb-3">
                  <span className="font-medium">Members:</span> {group.memberIds.length > 0 ? group.memberIds.map(id => getUserName(id, users)).join(', ') : 'No members yet'}
                </div>
              </div>
               <div className="mt-3 flex space-x-2 border-t dark:border-gray-700 pt-3">
                    <Button onClick={(e) => { e.stopPropagation(); handleOpenGroupForm(group);}} variant="ghost" size="sm" className="flex-1"><span className="flex items-center justify-center">{EditIcon} <span className="ml-1">Edit</span></span></Button>
                    <Button onClick={(e) => { e.stopPropagation(); handleDeleteGroup(group.id);}} variant="ghost" size="sm" className="text-red-500 hover:text-red-700 flex-1"><span className="flex items-center justify-center">{TrashIcon} <span className="ml-1">Delete</span></span></Button>
                </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Group Form Modal */}
      <Modal isOpen={showGroupForm} onClose={() => {setShowGroupForm(false); resetGroupForm();}} title={groupToEdit ? "Edit Group" : "Create New Group"}>
        <div className="space-y-4">
          <Input label="Group Name" value={groupName} onChange={e => setGroupName(e.target.value)} required />
          <Input label="Description (Optional)" value={groupDescription} onChange={e => setGroupDescription(e.target.value)} />
          <Select label="Default Currency" value={groupCurrency} onChange={e => setGroupCurrency(e.target.value as Currency)}>
            {CURRENCIES_LIST.map(c => <option key={c.code} value={c.code}>{c.name} ({c.symbol})</option>)}
          </Select>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-darkMuted mb-1">Members</label>
            <div className="space-y-1 max-h-48 overflow-y-auto border dark:border-gray-600 p-2 rounded-md bg-gray-50 dark:bg-gray-700/50">
              {users.length === 0 && <p className="text-xs text-gray-500 dark:text-darkMuted">No users available. Add users in Settings first or via 'Add New User' button below.</p>}
              {users.map(user => (
                <div key={user.id} className="flex items-center">
                  <input
                    type="checkbox"
                    id={`member-${user.id}`}
                    checked={groupMemberIds.includes(user.id)}
                    onChange={e => {
                      if (e.target.checked) {
                        setGroupMemberIds(prev => [...prev, user.id]);
                      } else {
                        setGroupMemberIds(prev => prev.filter(id => id !== user.id));
                      }
                    }}
                    className="h-4 w-4 text-primary border-gray-300 dark:border-gray-500 rounded focus:ring-primary mr-2"
                  />
                  <label htmlFor={`member-${user.id}`} className="text-sm text-gray-700 dark:text-darkText">{user.name}</label>
                </div>
              ))}
            </div>
            <Button type="button" variant="ghost" size="sm" onClick={() => setShowUserForm(s => !s)} className="mt-2">
              {showUserForm ? 'Cancel Add User' : '+ Add New User to List & Group'}
            </Button>
            {showUserForm && (
              <div className="mt-2 p-2 border dark:border-gray-600 rounded space-y-2 bg-gray-50 dark:bg-gray-700/50">
                <Input label="New User Name" value={newUserName} onChange={e => setNewUserName(e.target.value)} />
                <Button type="button" onClick={handleAddUser} variant="secondary" size="sm">Add User</Button>
              </div>
            )}
            {groupMemberIds.length === 0 && <p className="text-xs text-red-500 mt-1">A group must have at least one member.</p>}
          </div>
          <Button onClick={handleSaveGroup} className="w-full" size="lg">{groupToEdit ? "Save Changes" : "Create Group"}</Button>
        </div>
      </Modal>
    </div>
  );
};


// SETTINGS VIEW
export const SettingsView: React.FC<ViewProps> = ({ currentCurrency, setCurrentCurrency, users, setUsers, categories, setCategories, expenses, setExpenses, groups, setGroups }) => {
  const [newUserName, setNewUserName] = useState('');
  const [userToEdit, setUserToEdit] = useState<User | null>(null);

  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryIcon, setNewCategoryIcon] = useState('💡');
  const [categoryToEdit, setCategoryToEdit] = useState<Category | null>(null);

  const handleAddOrUpdateUser = () => {
    if(newUserName.trim() === '') return;
    if(userToEdit) {
        setUsers(prev => prev.map(u => u.id === userToEdit.id ? {...u, name: newUserName.trim()} : u));
        setUserToEdit(null);
    } else {
        setUsers(prev => [...prev, { id: generateId(), name: newUserName.trim() }]);
    }
    setNewUserName('');
  };

  const handleDeleteUser = (userId: string) => {
    const involvedInExpenses = expenses.some(e => e.paidByUserId === userId || e.participants?.some(p => p.userId === userId));
    const involvedInGroups = groups.some(g => g.memberIds.includes(userId));
    
    if (users.length <=1 && (involvedInExpenses || involvedInGroups)) {
       alert("Cannot delete the only user if they are involved in expenses or groups.");
       return;
    }
     if (users.length <=1) {
       alert("Cannot delete the only user. Add another user first.");
       return;
    }


    if (involvedInExpenses || involvedInGroups) {
        alert("Cannot delete user. They are part of active expenses or groups. Please remove them from all groups and expenses first, or reassign their expenses.");
        return;
    }
    if (window.confirm(`Are you sure you want to delete user "${getUserName(userId, users)}"? This action cannot be undone.`)) {
       setUsers(prev => prev.filter(u => u.id !== userId));
    }
  };

  const handleAddOrUpdateCategory = () => {
    if(newCategoryName.trim() === '') return;
    const catData = { name: newCategoryName.trim(), icon: newCategoryIcon.trim() || '💲' };
    if(categoryToEdit) {
        setCategories(prev => prev.map(c => c.id === categoryToEdit.id ? {...c, ...catData} : c));
        setCategoryToEdit(null);
    } else {
        setCategories(prev => [...prev, { id: generateId(), ...catData, isCustom: true }]);
    }
    setNewCategoryName('');
    setNewCategoryIcon('💡');
  };

   const handleDeleteCategory = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    if (!category || !category.isCustom) {
        alert("Default categories cannot be deleted.");
        return;
    }
    const isUsed = expenses.some(e => e.categoryId === categoryId);
    if (isUsed) {
        alert("Cannot delete category. It's used in some expenses. Re-categorize those expenses first.");
        return;
    }
     if (window.confirm(`Delete category "${category.name}"?`)) {
       setCategories(prev => prev.filter(c => c.id !== categoryId));
    }
  };
  
  const handleExportData = () => {
    const dataToExport = { users, categories, expenses, groups, currentCurrency, theme: document.documentElement.classList.contains('dark') ? 'dark' : 'light' };
    try {
        const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(dataToExport, null, 2))}`;
        const link = document.createElement("a");
        link.href = jsonString;
        link.download = `splitsmart_backup_${new Date().toISOString().split('T')[0]}.json`;
        link.click();
        alert("Data exported successfully!");
    } catch(error) {
        console.error("Error exporting data:", error);
        alert("Failed to export data. Check console for details.");
    }
  };

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const text = e.target?.result;
            if (typeof text === 'string') {
                const importedData = JSON.parse(text);
                if (window.confirm("Importing data will overwrite existing data. Are you sure you want to proceed?")) {
                    setUsers(importedData.users || DEFAULT_USERS);
                    setCategories(importedData.categories || DEFAULT_CATEGORIES);
                    setExpenses(importedData.expenses || []);
                    setGroups(importedData.groups || []);
                    setCurrentCurrency(importedData.currentCurrency || Currency.USD);
                    // setTheme(importedData.theme || 'light'); // Theme is handled by useLocalStorage directly
                    alert("Data imported successfully! The page will reload to apply all changes.");
                    window.location.reload(); // Reload to ensure all states are fresh
                }
            }
        } catch (error) {
            console.error("Error importing data:", error);
            alert("Failed to import data. The file might be corrupted or not in the correct format.");
        }
    };
    reader.readAsText(file);
    event.target.value = ''; // Reset file input
  };

  const handleClearAllData = () => {
    if (window.confirm("DANGER! This will delete ALL your data (expenses, groups, users, categories). This action cannot be undone. Are you absolutely sure?")) {
        if (window.confirm("SECOND WARNING: This is permanent. Confirm again to delete all data.")) {
            setExpenses([]);
            setGroups([]);
            setUsers(DEFAULT_USERS); 
            setCategories(DEFAULT_CATEGORIES);
            setCurrentCurrency(Currency.USD);
            localStorage.removeItem('splitSmartUsers');
            localStorage.removeItem('splitSmartCategories');
            localStorage.removeItem('splitSmartExpenses');
            localStorage.removeItem('splitSmartGroups');
            localStorage.removeItem('splitSmartCurrency');
            alert("All data has been cleared. The page will reload.");
            window.location.reload();
        }
    }
  };

  return (
    <div className="p-4 space-y-8 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-darkText text-center">Settings</h1>

      <div className="p-6 bg-white dark:bg-darkSurface shadow-lg rounded-xl">
        <h2 className="text-xl font-semibold text-gray-700 dark:text-darkMuted mb-3">Default Currency</h2>
        <Select value={currentCurrency} onChange={e => setCurrentCurrency(e.target.value as Currency)} className="text-base">
          {CURRENCIES_LIST.map(c => <option key={c.code} value={c.code}>{c.name} ({c.symbol})</option>)}
        </Select>
      </div>

      {/* Manage Users */}
      <div className="p-6 bg-white dark:bg-darkSurface shadow-lg rounded-xl">
        <h2 className="text-xl font-semibold text-gray-700 dark:text-darkMuted mb-4">Manage Users</h2>
        <div className="flex gap-2 mb-4">
            <Input placeholder="User name" value={newUserName} onChange={e => setNewUserName(e.target.value)} className="flex-grow text-base" />
            <Button onClick={handleAddOrUpdateUser} variant={userToEdit ? "secondary" : "primary"}>{userToEdit ? 'Update User' : 'Add User'}</Button>
            {userToEdit && <Button variant="ghost" onClick={() => {setUserToEdit(null); setNewUserName('');}}>Cancel</Button>}
        </div>
        <ul className="space-y-2 max-h-60 overflow-y-auto pretty-scrollbar pr-2">
            {users.map(u => (
                <li key={u.id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <span className="flex items-center">{UserCircleIcon} <span className="ml-2">{u.name}</span></span>
                    <div>
                        <Button variant="ghost" size="sm" onClick={() => {setUserToEdit(u); setNewUserName(u.name);}} className="p-1">{EditIcon}</Button>
                        <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700 p-1" onClick={() => handleDeleteUser(u.id)} disabled={users.length <=1}>{TrashIcon}</Button>
                    </div>
                </li>
            ))}
        </ul>
      </div>
      
      {/* Manage Categories */}
      <div className="p-6 bg-white dark:bg-darkSurface shadow-lg rounded-xl">
        <h2 className="text-xl font-semibold text-gray-700 dark:text-darkMuted mb-4">Manage Categories</h2>
         <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-3 items-end">
            <Input className="sm:col-span-2 text-base" placeholder="Category name" label="Name" value={newCategoryName} onChange={e => setNewCategoryName(e.target.value)} />
            <Input placeholder="Icon" label="Icon (Emoji)" value={newCategoryIcon} onChange={e => setNewCategoryIcon(e.target.value)} maxLength={2} className="text-base"/>
        </div>
        <div className="flex gap-2 mb-4">
            <Button onClick={handleAddOrUpdateCategory} variant={categoryToEdit ? "secondary" : "primary"} className="w-full">{categoryToEdit ? 'Update Category' : 'Add Category'}</Button>
            {categoryToEdit && <Button variant="ghost" onClick={() => {setCategoryToEdit(null); setNewCategoryName(''); setNewCategoryIcon('💡');}} className="w-full">Cancel Edit</Button>}
        </div>
        <ul className="space-y-2 max-h-60 overflow-y-auto pretty-scrollbar pr-2">
            {categories.map(c => (
                <li key={c.id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <span>{c.icon} {c.name} {c.isCustom && <span className="text-xs text-gray-500 dark:text-gray-400">(Custom)</span>}</span>
                    {c.isCustom && ( 
                        <div>
                            <Button variant="ghost" size="sm" onClick={() => {setCategoryToEdit(c); setNewCategoryName(c.name); setNewCategoryIcon(c.icon);}} className="p-1">{EditIcon}</Button>
                            <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700 p-1" onClick={() => handleDeleteCategory(c.id)}>{TrashIcon}</Button>
                        </div>
                    )}
                </li>
            ))}
        </ul>
      </div>

      <div className="p-6 bg-white dark:bg-darkSurface shadow-lg rounded-xl space-y-4">
        <h2 className="text-xl font-semibold text-gray-700 dark:text-darkMuted mb-3">Data Management</h2>
        <Button onClick={handleExportData} variant="secondary" className="w-full flex items-center justify-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" /></svg>
            Export My Data (JSON)
        </Button>
        
        <div>
            <label htmlFor="import-file" className="w-full cursor-pointer bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-darkSurface transition-all duration-150 ease-in-out flex items-center justify-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" /></svg>
                Import Data (JSON)
            </label>
            <input type="file" id="import-file" accept=".json" onChange={handleImportData} className="hidden" />
        </div>
        
        <Button onClick={handleClearAllData} variant="danger" className="w-full flex items-center justify-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" /></svg>
            Clear All Application Data
        </Button>
        <p className="text-xs text-gray-500 dark:text-darkMuted">Exporting data allows you to back up your information. Importing will overwrite current data. Clearing data is permanent.</p>
      </div>
    </div>
  );
};

// Helper for scrollbar styling - can be added to index.html or a global css if preferred
// This is a TSX file, so CSS is best handled via Tailwind or inline for component-specifics
// For global scrollbar, Tailwind plugins or index.css is better. We'll use a simple utility class name.
// Add to your tailwind.config.js (if you had one and were not using CDN) or directly use these styles where needed if simple.
// For now, added a class `pretty-scrollbar` and assumed it might be defined in index.html's tailwind config or custom CSS.
// If not, the scrollbars will be default.
// Example for `pretty-scrollbar` (conceptual, as direct CSS isn't used here):
/*
.pretty-scrollbar::-webkit-scrollbar {
  width: 8px;
}
.pretty-scrollbar::-webkit-scrollbar-track {
  background: transparent;
}
.pretty-scrollbar::-webkit-scrollbar-thumb {
  background-color: rgba(0,0,0,0.2);
  border-radius: 4px;
}
.dark .pretty-scrollbar::-webkit-scrollbar-thumb {
  background-color: rgba(255,255,255,0.2);
}
*/
// The `pretty-scrollbar` class has been added to user list and category list in Settings.
// If you have `tailwind.config.js`, you can add a scrollbar plugin for better global control.
// e.g. `require('tailwind-scrollbar-hide')` or `require('tailwind-scrollbar')`
// For CDN use, custom CSS in <style> tag in index.html is an option for this.
// For simplicity, will assume default browser scrollbars are acceptable if `pretty-scrollbar` is not globally defined.