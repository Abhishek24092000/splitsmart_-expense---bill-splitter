import { Expense, Group, User, Currency, Settlement, Category, RecurrenceInterval } from '../types';
import { CURRENCIES_LIST } from '../constants';

export const generateId = (): string => `id_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

export const formatCurrency = (amount: number, currencyCode: Currency): string => {
  const currencyInfo = CURRENCIES_LIST.find(c => c.code === currencyCode);
  const symbol = currencyInfo ? currencyInfo.symbol : '$';
  try {
    return `${symbol}${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  } catch (e) {
    // Fallback for environments where toLocaleString might fail with currency options
    return `${symbol}${amount.toFixed(2)}`;
  }
};


export const calculateGroupBalances = (
  groupId: string,
  allExpenses: Expense[],
  groups: Group[],
  users: User[]
): Map<string, number> => {
  const group = groups.find(g => g.id === groupId);
  if (!group) return new Map();

  const groupExpenses = allExpenses.filter(exp => exp.groupId === groupId);
  const balances = new Map<string, number>();

  group.memberIds.forEach(memberId => balances.set(memberId, 0));

  groupExpenses.forEach(expense => {
    const payerId = expense.paidByUserId;
    // Credit the payer
    balances.set(payerId, (balances.get(payerId) || 0) + expense.amount);

    // Debit participants
    if (expense.participants && expense.participants.length > 0) {
      expense.participants.forEach(participant => {
        balances.set(participant.userId, (balances.get(participant.userId) || 0) - participant.share);
      });
    } else {
      // If no specific participants, assume all group members participated equally (old model)
      // This path should ideally not be taken if participants are always defined for group expenses
      const numMembers = group.memberIds.length;
      if (numMembers > 0) {
        const share = expense.amount / numMembers;
        group.memberIds.forEach(memberId => {
          balances.set(memberId, (balances.get(memberId) || 0) - share);
        });
      }
    }
  });
  return balances;
};

export const simplifyDebts = (balances: Map<string, number>, currency: Currency): Settlement[] => {
  const settlements: Settlement[] = [];
  const debtors: { id: string; amount: number }[] = [];
  const creditors: { id: string; amount: number }[] = [];

  balances.forEach((amount, userId) => {
    if (amount < -0.001) { // Use a small epsilon for float comparisons
      debtors.push({ id: userId, amount: Math.abs(amount) });
    } else if (amount > 0.001) {
      creditors.push({ id: userId, amount: amount });
    }
  });

  debtors.sort((a, b) => b.amount - a.amount);
  creditors.sort((a, b) => b.amount - a.amount);

  let debtorIdx = 0;
  let creditorIdx = 0;

  while (debtorIdx < debtors.length && creditorIdx < creditors.length) {
    const debtor = debtors[debtorIdx];
    const creditor = creditors[creditorIdx];
    const amountToSettle = Math.min(debtor.amount, creditor.amount);

    if (amountToSettle > 0.001) { // Only create settlement if amount is significant
        settlements.push({
            fromUserId: debtor.id,
            toUserId: creditor.id,
            amount: amountToSettle,
            currency: currency,
        });
    }

    debtor.amount -= amountToSettle;
    creditor.amount -= amountToSettle;

    if (debtor.amount < 0.001) debtorIdx++;
    if (creditor.amount < 0.001) creditorIdx++;
  }
  return settlements;
};

export const getCategoryName = (categoryId: string, categories: Category[]): string => {
  return categories.find(c => c.id === categoryId)?.name || 'Unknown';
};

export const getUserName = (userId: string, users: User[]): string => {
  return users.find(u => u.id === userId)?.name || 'Unknown User';
};

export const getCategoryIcon = (categoryId: string, categories: Category[]): string => {
  return categories.find(c => c.id === categoryId)?.icon || '❔';
};

export const processRecurringExpenses = (expenses: Expense[]): { newExpenses: Expense[], updatedRecurringExpenses: Expense[] } => {
  const today = new Date();
  today.setHours(0,0,0,0); // Normalize to start of day for comparison

  const newGeneratedExpenses: Expense[] = [];
  const updatedRecurringTemplates: Expense[] = [];

  expenses.filter(e => e.isRecurring && e.nextRecurrenceDate).forEach(templateExpense => {
    let nextRecurrence = new Date(templateExpense.nextRecurrenceDate!);
    nextRecurrence.setHours(0,0,0,0);

    if (nextRecurrence <= today) {
      // Create new expense instance
      const newExpense: Expense = {
        ...templateExpense,
        id: generateId(),
        isRecurring: false, // This instance is not a template
        date: nextRecurrence.toISOString().split('T')[0], // Use the recurrence date as the expense date
        // notes: `Recurring expense from template: ${templateExpense.description}`,
        // nextRecurrenceDate should not be on this instance
      };
      delete newExpense.nextRecurrenceDate;
      delete newExpense.recurrenceInterval;


      newGeneratedExpenses.push(newExpense);

      // Update template's nextRecurrenceDate
      let updatedNextDate = new Date(nextRecurrence);
      switch (templateExpense.recurrenceInterval) {
        case RecurrenceInterval.DAILY: updatedNextDate.setDate(updatedNextDate.getDate() + 1); break;
        case RecurrenceInterval.WEEKLY: updatedNextDate.setDate(updatedNextDate.getDate() + 7); break;
        case RecurrenceInterval.MONTHLY: updatedNextDate.setMonth(updatedNextDate.getMonth() + 1); break;
        case RecurrenceInterval.YEARLY: updatedNextDate.setFullYear(updatedNextDate.getFullYear() + 1); break;
        default: // Should not happen if interval is always set
          updatedNextDate.setDate(updatedNextDate.getDate() + 7); // Default to weekly if somehow unset
          break;
      }
      updatedRecurringTemplates.push({ ...templateExpense, nextRecurrenceDate: updatedNextDate.toISOString().split('T')[0] });
    } else {
      // If not due, keep original template
      updatedRecurringTemplates.push(templateExpense);
    }
  });
  
  // Filter out old templates that have been updated
  const nonUpdatedRecurring = expenses.filter(e => !(e.isRecurring && e.nextRecurrenceDate && updatedRecurringTemplates.find(ut => ut.id === e.id)));
  
  return { newExpenses: newGeneratedExpenses, updatedRecurringExpenses: [...nonUpdatedRecurring, ...updatedRecurringTemplates] };
};

// Utility for chart data preparation
export interface CategorySpending {
  name: string;
  value: number;
}
export const aggregateSpendingByCategory = (expenses: Expense[], categories: Category[], selectedCurrency: Currency): CategorySpending[] => {
    const spendingMap = new Map<string, number>();
    expenses
      .filter(e => e.currency === selectedCurrency && !e.isRecurring) // Only non-template expenses for actual spending
      .forEach(expense => {
        const currentTotal = spendingMap.get(expense.categoryId) || 0;
        spendingMap.set(expense.categoryId, currentTotal + expense.amount);
    });

    return Array.from(spendingMap.entries()).map(([categoryId, total]) => ({
        name: getCategoryName(categoryId, categories),
        value: total,
    })).sort((a,b) => b.value - a.value);
};

export interface MonthlySpending {
  month: string;
  value: number;
}
export const aggregateSpendingByMonth = (expenses: Expense[], selectedCurrency: Currency): MonthlySpending[] => {
    const spendingMap = new Map<string, number>(); // Key: YYYY-MM
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    expenses
      .filter(e => e.currency === selectedCurrency && !e.isRecurring)
      .forEach(expense => {
        const date = new Date(expense.date);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`; // YYYY-MM
        const currentTotal = spendingMap.get(monthKey) || 0;
        spendingMap.set(monthKey, currentTotal + expense.amount);
    });
    
    return Array.from(spendingMap.entries())
        .map(([monthKey, total]) => {
            const [year, monthNum] = monthKey.split('-');
            return {
                month: `${monthNames[parseInt(monthNum,10)-1]} ${year.slice(2)}`, // e.g., Jan '23
                value: total,
            };
        })
        .sort((a,b) => { // Sort by date
            const [aMon, aYr] = a.month.split(' ');
            const [bMon, bYr] = b.month.split(' ');
            const aDate = new Date(`${aMon} 1, 20${aYr}`);
            const bDate = new Date(`${bMon} 1, 20${bYr}`);
            return aDate.getTime() - bDate.getTime();
        });
};