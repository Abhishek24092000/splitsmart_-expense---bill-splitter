
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Expense, Category, Currency } from '../types';
import { aggregateSpendingByCategory } from '../utils/helpers';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. Smart features will be disabled. Ensure process.env.API_KEY is set.");
}

const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

export const getSavingsTips = async (
  expenses: Expense[],
  categories: Category[],
  selectedCurrency: Currency
): Promise<string[]> => {
  if (!ai) {
    return ["Savings tips are unavailable. API key not configured."];
  }

  const spendingByCategory = aggregateSpendingByCategory(expenses, categories, selectedCurrency);
  if (spendingByCategory.length === 0) {
    return ["Not enough spending data to generate tips. Add some expenses!"];
  }

  const promptParts: string[] = ["Based on the following monthly spending data (approximate):"];
  spendingByCategory.slice(0, 5).forEach(item => { // Top 5 categories
    promptParts.push(`${item.name}: ${item.value.toFixed(0)} ${selectedCurrency}`);
  });
  promptParts.push("\nProvide 3 actionable and concise savings tips. Each tip should be a short sentence. Focus on practical advice.");
  
  const prompt = promptParts.join('\n');

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-preview-04-17',
      contents: prompt,
    });
    const text = response.text;
    // Gemini might return tips starting with "-", "*", or numbers. Clean them up.
    return text.split('\n').map(tip => tip.trim().replace(/^[\*\-\d\.]+\s*/, '')).filter(tip => tip.length > 5);
  } catch (error) {
    console.error("Error fetching savings tips from Gemini:", error);
    if (error instanceof Error && error.message.includes("API key not valid")) {
        return ["Could not fetch savings tips. Please check your Gemini API key."];
    }
    return ["Could not fetch savings tips at this time. Please try again later."];
  }
};
